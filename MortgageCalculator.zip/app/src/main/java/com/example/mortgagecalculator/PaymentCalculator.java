package com.example.mortgagecalculator;

public class PaymentCalculator {

    private double principal;
    private double annualRate;
    private int numberOfPayments;
    private double r;
    private double total = 0;
    private double monthlyPayment;
    private int counter = 0;
    private int years;
    private int months;
    private double lastPayment;


    private int period;


    public PaymentCalculator(double principal, double annualRate){
        this.principal = principal;
        this.annualRate = annualRate;
        this.r = annualRate / 100 / 12;
    }


    public double calculateMonthlyPayment(){
        double mp = this.principal * ((this.r * Math.pow(1 + r, this.numberOfPayments)) / (Math.pow(1 + this.r, this.numberOfPayments) -1));
        total = getNumberOfPayments() * mp;
        return mp;
    }

    public boolean calculatePeriod(){
        double checker = principal;
        total = principal;
        double r = this.annualRate / 100 / 12;
        while (this.principal >= 0) {
            this.principal += this.principal * r;
            this.total += this.principal * r;
            principal -= monthlyPayment;
            counter++;
            if(checker <= principal){
                return false;
            }
        }
        lastPayment = monthlyPayment + principal;
        this.years = counter / 12;
        this.months = counter - years * 12;
        return true;
    }

    public void setPeriod(int period) {
        this.period = period;
        numberOfPayments = period * 12;
    }

    public int getNumberOfPayments() {
        return numberOfPayments;
    }

    public double getTotal() {
        return total;
    }

    public double getMonthlyPayment() {
        return monthlyPayment;
    }

    public void setMonthlyPayment(double monthlyPayment) {
        this.monthlyPayment = monthlyPayment;
    }

    public int getYears() {
        return years;
    }

    public int getMonths() {
        return months;
    }

    public double getLastPayment() {
        return lastPayment;
    }

}
